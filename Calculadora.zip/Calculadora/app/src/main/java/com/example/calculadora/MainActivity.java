package com.example.calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.widget.Button;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.textView)
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
    }


   @OnClick({R.id.btn_0, R.id.btn_1 , R.id.btn_2 , R.id.btn_3 , R.id.btn_4 , R.id.btn_5 , R.id.btn_6 , R.id.btn_7 , R.id.btn_8 , R.id.btn_9 , R.id.btn_decimal , R.id.btn_igual })
           protected void onNumeroClicked(Button button){
        textView.setText(button.getText().toString());
    }


    @OnClick({R.id.btn_suma , R.id.btn_resta , R.id.btn_multiplicacion , R.id.btn_division})
    protected void onOperadorClicked(Button button){
        textView.setText(button.getText().toString());
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }
}
